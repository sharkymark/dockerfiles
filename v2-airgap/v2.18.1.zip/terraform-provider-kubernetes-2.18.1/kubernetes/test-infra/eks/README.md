# EKS Managed Node Group Example

This is a minimal configuration to provision an EKS cluster for testing purposes.