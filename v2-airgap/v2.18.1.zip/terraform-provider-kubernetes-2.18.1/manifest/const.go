package manifest

const (
	PreserveUnknownFieldsLabel string = "x-kubernetes-preserve-unknown-fields"
)
